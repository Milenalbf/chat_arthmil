# Ateliê — Central de Atendimento

Interface responsiva para organização de conversas e contatos, desenvolvida com **HTML5, CSS3 e JavaScript puro**.

## Funcionalidades

- Listagem de conversas com pesquisa e filtros por status.
- Leitura e registro local de mensagens.
- Arquivamento e recuperação de conversas.
- Consulta às informações do contato.
- Anexos de texto (`.txt`, `.csv`, `.json` e `.md`) com limite de 2 MB por arquivo.
- Layout responsivo para desktop e celular.
- Persistência local via `localStorage`.

## Executar

Abra `index.html` no navegador. Para desenvolvimento, é recomendável usar um servidor local (por exemplo, a extensão **Live Server** do VS Code).

## Estrutura

```text
.
├── index.html          # Estrutura semântica da aplicação
├── assets/
│   └── logo.jpeg       # Identidade visual
├── css/
│   ├── style.css       # Estilos principais
│   ├── mobile.css      # Estilos responsivos
│   ├── components.css  # Componentes e estados
│   └── brand.css       # Identidade visual do Ateliê
├── js/
│   └── app.js          # Estado, eventos e persistência
└── README.md
```

## Limitações atuais

**Este projeto é um frontend estático.** Os contatos iniciais são dados ilustrativos. Mensagens e anexos adicionados **não são enviados a destinatários nem a servidores**: são armazenados somente no `localStorage` do navegador. Não há autenticação, banco de dados, sincronização entre dispositivos ou integração com WhatsApp, e-mail ou outras plataformas.

Por isso, **não utilize dados pessoais reais ou confidenciais nesta versão**. Para uso em produção, implemente uma API segura, autenticação, autorização, armazenamento adequado e política de proteção de dados.

## Próximas melhorias

- API com autenticação e banco de dados.
- Integração com serviço de atendimento ou mensageria.
- Testes automatizados e validação de acessibilidade.
- Paginação e carregamento eficiente de históricos longos.

## Licenciamento

Defina uma licença antes de disponibilizar o projeto para reutilização por terceiros.
