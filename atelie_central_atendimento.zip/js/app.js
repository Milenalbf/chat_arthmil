"use strict";
/**
 * Ateliê | Central de Atendimento
 * Interface estática com persistência no localStorage.
 * Sem API ou integração de mensagens: registros incluídos aqui ficam neste navegador.
 */
const KEY="atelie_conversations_v1";
const $=(selector)=>document.querySelector(selector);
const $$=(selector)=>Array.from(document.querySelectorAll(selector));
const now=()=>new Date().toISOString();
const time=(iso)=>new Date(iso).toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"});
const date=(iso)=>new Date(iso).toLocaleDateString("pt-BR",{day:"2-digit",month:"2-digit"});
const examples=[
 {id:"c1",name:"Ana Oliveira",email:"ana.oliveira@exemplo.com",phone:"(11) 90000-1001",category:"Suporte",tags:["Dúvida","Novo contato"],unread:2,archived:false,messages:[{sender:"client",text:"Olá! Poderia me ajudar com o acesso à plataforma?",minutes:-85},{sender:"agent",text:"Olá, Ana! Claro, qual dificuldade está encontrando?",minutes:-83},{sender:"client",text:"Esqueci minha senha. Você tem um guia?",minutes:-15},{sender:"client",file:{name:"guia-acesso.txt",type:"text/plain",content:"Guia ilustrativo de acesso\n\n1. Acesse o site local.\n2. Selecione Recuperar senha.\n3. Siga as instruções da tela.\n\nDocumento de referência."},minutes:-10}]},
 {id:"c2",name:"Bruno Martins",email:"bruno.martins@exemplo.com",phone:"(21) 90000-1002",category:"Comercial",tags:["Orçamento"],unread:0,archived:false,messages:[{sender:"client",text:"Bom dia! Gostaria de receber um orçamento.",minutes:-240},{sender:"agent",text:"Olá, Bruno! Segue um exemplo de proposta para avaliação.",minutes:-230},{sender:"agent",file:{name:"proposta-exemplo.txt",type:"text/plain",content:"PROPOSTA COMERCIAL\nItem local A - 2 unidades\nValor ilustrativo: R$ 200,00\nDocumento de referência."},minutes:-229},{sender:"client",text:"Obrigado pelo retorno!",minutes:-100}]},
 {id:"c3",name:"Carla Ferreira",email:"carla.ferreira@exemplo.com",phone:"(31) 90000-1003",category:"Financeiro",tags:["Documento"],unread:1,archived:false,messages:[{sender:"client",text:"Boa tarde, pode conferir o arquivo que enviei?",minutes:-110},{sender:"client",file:{name:"fatura-registrada.csv",type:"text/csv",content:"descricao,quantidade,valor\nServiço ilustrativo,1,150.00\nTotal,1,150.00"},minutes:-109}]},
 {id:"c4",name:"Diego Costa",email:"diego.costa@exemplo.com",phone:"(41) 90000-1004",category:"Atendimento",tags:["Resolvido"],unread:0,archived:false,messages:[{sender:"client",text:"O problema já foi resolvido.",minutes:-420},{sender:"agent",text:"Perfeito! Sempre que precisar, estamos à disposição.",minutes:-410}]},
 {id:"c5",name:"Elisa Ribeiro",email:"elisa.ribeiro@exemplo.com",phone:"(51) 90000-1005",category:"Suporte",tags:["Acompanhamento"],unread:0,archived:true,messages:[{sender:"client",text:"Envio abaixo as informações solicitadas.",minutes:-1600},{sender:"client",file:{name:"dados-teste.json",type:"application/json",content:'{"projeto":"Ateliê","status":"Exemplo","itens":[1,2,3]}'},minutes:-1599},{sender:"agent",text:"Recebido, obrigada!",minutes:-1590}]},
 {id:"c6",name:"Felipe Almeida",email:"felipe.almeida@exemplo.com",phone:"(61) 90000-1006",category:"Geral",tags:["Informações"],unread:0,archived:false,messages:[{sender:"client",text:"Vocês atendem aos sábados?",minutes:-62},{sender:"agent",text:"No momento, consulte nossa equipe para confirmar os horários de atendimento.",minutes:-60}]}
];
// Gera os registros iniciais e os horários relativos ao carregamento.
function seed(){return examples.map(c=>({...c,messages:c.messages.map(m=>({sender:m.sender,text:m.text||"",file:m.file||null,at:new Date(Date.now()+m.minutes*60000).toISOString()}))}));}
// Recupera os dados locais; utiliza os registros iniciais se não houver dados válidos.
function load(){try{const v=JSON.parse(localStorage.getItem(KEY));return Array.isArray(v)&&v.length?v:seed();}catch{return seed();}}
let contacts=load();let selected=contacts.find(c=>!c.archived)?.id||contacts[0].id;let filter="all";let search="";
function save(){try{localStorage.setItem(KEY,JSON.stringify(contacts));}catch(e){console.warn("Não foi possível salvar localmente",e);}}
// Escapa texto antes de inseri-lo no HTML para prevenir injeção de marcação.
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
const active=()=>contacts.find(c=>c.id===selected);
function last(c){return c.messages[c.messages.length-1]||{};}
// Aplica filtros e atualiza a lista de conversas.
function renderList(){const total=contacts.filter(c=>!c.archived).length;$("#totalCount").textContent=`${total} ativas`;
 $$(".ui-tabs button").forEach(b=>((b.classList.toggle("is-active",b.dataset.filter===filter)),b.setAttribute("aria-pressed",String(b.dataset.filter===filter))));
 let list=contacts.filter(c=>(filter==="archived"?c.archived:!c.archived)&&(filter!=="unread"||c.unread>0)&&(`${c.name} ${c.email} ${c.category}`).toLowerCase().includes(search));
 list.sort((a,b)=>new Date(last(b).at)-new Date(last(a).at));
 $("#conversationList").innerHTML=list.length?list.map(c=>`<div class="conversation ${c.id===selected?'active':''} ${c.unread?'has-unread':''} ${c.archived?'is-archived':''}" data-id="${c.id}" tabindex="0" role="button"><div class="avatar">${esc(c.name.split(' ').map(x=>x[0]).slice(0,2).join(''))}</div><div class="conversation-data"><div class="conversation-title"><strong>${esc(c.name)}</strong><time>${time(last(c).at)}</time></div><p>${esc(last(c).file?'📎 '+last(c).file.name:last(c).text||'Sem mensagens')}</p><div class="ui-conversation-meta"><span class="ui-tag">${esc(c.category)}</span>${c.unread?`<span class="ui-badge">${c.unread}</span>`:''}</div></div></div>`).join(''):'<div class="ui-empty">Nenhuma conversa encontrada.</div>';
 $$(".conversation[data-id]").forEach(el=>{const open=()=>select(el.dataset.id);el.addEventListener("click",open);el.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();open();}});});}
function select(id){selected=id;const c=active();if(!c)return;c.unread=0;save();renderList();renderChat();$(".chat-layout").classList.add("ui-mobile-open");}
function fileURL(file){const blob=new Blob([file.content||"Arquivo indisponível."],{type:file.type||'text/plain'});return URL.createObjectURL(blob);}
// Atualiza a conversa e as informações associadas ao contato.
function renderChat(){const c=active();if(!c)return;const initials=c.name.split(' ').map(x=>x[0]).slice(0,2).join('');$("#chatAvatar").textContent=initials;$("#contactAvatar").textContent=initials;$("#chatName").textContent=c.name;$("#chatStatus").textContent=c.archived?"Conversa arquivada":"Atendimento";$("#contactName").textContent=c.name;$("#contactFullName").textContent=c.name;$("#contactEmail").textContent=c.email;$("#contactPhone").textContent=c.phone;$("#contactCategory").textContent=c.category;$("#contactTags").innerHTML=c.tags.map(x=>`<span class="ui-tag">${esc(x)}</span>`).join('');$("#contactServiceCount").textContent=String(c.messages.length);$("#contactLastService").textContent=date(last(c).at);$("#archiveButton").textContent=c.archived?"Desarquivar":"Arquivar";
 $("#messages").innerHTML=c.messages.map((m,i)=>`<div class="message ${m.sender==='agent'?'attendant':'client'}"><div class="bubble">${m.file?`<a href="#" class="ui-file" data-file="${i}"><span class="ui-file-icon">📄</span><span><span class="ui-file-title">${esc(m.file.name)}</span><span class="ui-file-caption">Baixar anexo</span></span></a>`:`<p>${esc(m.text)}</p>`}<div class="message-time">${time(m.at)} </div></div></div>`).join('');
 $$("[data-file]").forEach(a=>a.addEventListener('click',e=>{e.preventDefault();const f=c.messages[Number(a.dataset.file)].file;const url=fileURL(f);const link=document.createElement('a');link.href=url;link.download=f.name.replace(/[\/\\]/g,"_");document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);}));
 $("#messageInput").disabled=c.archived;$("#sendButton").disabled=c.archived;$("#fileInput").disabled=c.archived;$("#messageInput").placeholder=c.archived?"Desarquive para responder...":"Digite uma mensagem...";$("#messages").scrollTop=$("#messages").scrollHeight;}
// Adiciona uma mensagem ao histórico local (não envia à rede).
function sendMessage(){const text=$("#messageInput").value.trim(),c=active();if(!text||!c||c.archived)return;c.messages.push({sender:"agent",text,at:now()});$("#messageInput").value="";save();renderList();renderChat();}
$("#sendButton").addEventListener("click",sendMessage);$("#messageInput").addEventListener("keydown",e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage();}});
$("#searchConversation").addEventListener("input",e=>{search=e.target.value.trim().toLowerCase();renderList();});
$$(".ui-tabs button").forEach(b=>b.addEventListener("click",()=>{filter=b.dataset.filter;renderList();}));
$("#archiveButton").addEventListener("click",()=>{const c=active();if(!c)return;c.archived=!c.archived;save();renderList();renderChat();});
$("#mobileChatBack").addEventListener("click",()=>$(".chat-layout").classList.remove("ui-mobile-open"));
$("#navReset").addEventListener("click",()=>{if(confirm("Deseja descartar as alterações feitas neste navegador e restaurar as conversas iniciais?")){contacts=seed();selected=contacts[0].id;filter="all";search="";$("#searchConversation").value="";save();renderList();renderChat();}});
$("#navChats").addEventListener("click",()=>{$(".chat-layout").classList.remove("ui-mobile-open");});
$("#fileInput").addEventListener("change",async e=>{const c=active();if(!c||c.archived)return;for(const file of Array.from(e.target.files||[])){if(file.size>2*1024*1024){alert(`Arquivo ${file.name} ultrapassa 2 MB. Selecione um arquivo menor.`);continue;}if(!(/^(text\/|application\/json$)/.test(file.type)||/\.(txt|csv|json|md)$/i.test(file.name))){alert(`Formato não permitido: ${file.name}.`);continue;}const contents=await file.text();c.messages.push({sender:"agent",file:{name:file.name,type:file.type||'text/plain',content:contents},text:"",at:now()});}e.target.value="";save();renderList();renderChat();});
renderList();renderChat();
